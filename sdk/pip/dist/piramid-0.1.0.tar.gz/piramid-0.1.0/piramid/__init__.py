"""Piramid SDK - Vector database for agentic applications."""

__version__ = "0.1.0"

def hello():
    """Minimal placeholder function."""
    return "Piramid vector database SDK"
